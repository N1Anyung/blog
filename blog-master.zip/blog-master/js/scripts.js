document.addEventListener('DOMContentLoaded', ()=>{
    const token = localStorage.getItem('token');
    const users = localStorage.getItem('users');
    const currentUser = localStorage.getItem('currentUser');

    function noPost() {
        const noPosts = document.createElement('div');
        noPosts.classList.add('container');
        noPosts.style.display = 'flex';
        noPosts.style.justifyContent = 'center';
        noPosts.style.alignItems = 'center';
        noPosts.style.flexDirection = 'column';

        noPosts.style.height = '80vh';


        const noPostContent = document.createElement('h1');
        noPostContent.textContent = 'No Posts Yet'
        noPostContent.style.padding = '5px 10px';
        noPosts.appendChild(noPostContent);

        const newPostsLink = document.createElement('p');
        newPostsLink.innerHTML = '<a href="new-post.html" style="font-size: 1.3rem; color: #eeeeee"><i class="fa-solid fa-plus-square" style="font-size: 1.3rem"></i> Add new post</a>';
        newPostsLink.style.padding = '5px 10px';
        noPosts.appendChild(newPostsLink);

        document.body.appendChild(noPosts)
    }

    if(!token){
        if(currentUser && !window.location.href.endsWith('login.html') && !window.location.href.endsWith('register.html')){
            window.open('login.html', '_self');
            return;
        } else if (!users && !currentUser && !window.location.href.endsWith('register.html')){
            window.open('register.html', '_self');
            return;
        }
        return;
    } else {
        if(currentUser && window.location.href.endsWith('index.html')) {
            const localPosts = localStorage.getItem('posts');
            const currentUser = localStorage.getItem('currentUser');
            if (localPosts && currentUser) {
                const posts = JSON.parse(localPosts);
                if(posts.length === 0){
                    noPost();
                    return;
                }
                const allPosts = document.createElement('div');
                posts.forEach((post, index) => {
                    allPosts.classList.add('container');
                    allPosts.style.flexDirection = 'column'

                    const postDiv = document.createElement('div');
                    postDiv.classList.add('post-div');

                    const top = document.createElement('div');
                    top.style.height = '30px';
                    top.style.display = 'flex';
                    top.style.justifyContent = 'space-between';
                    top.style.alignItems = 'center';
                    top.style.width = '100%';
                    top.style.padding = '5px 10px';

                    const currentUserName = document.createElement('span');
                    currentUserName.style.height = '100%';
                    currentUserName.style.width = '100%';
                    currentUserName.style.display = 'flex';
                    currentUserName.style.justifyContent = 'start';
                    currentUserName.style.alignItems = 'center';
                    currentUserName.innerHTML = "<span style='width: 30px; height: 30px; border-radius: 50%; background-color: #eeeeee; margin-right: 10px'></span>" + post.author;
                    currentUserName.style.paddingLeft = '10px';

                    top.appendChild(currentUserName)

                    if(post.author === currentUser) {
                        const remove = document.createElement('span');
                        remove.innerHTML = '✖';
                        remove.style.paddingRight = '10px';
                        remove.style.textAlign = 'right';
                        remove.style.cursor = 'pointer';
                        remove.title = 'Удалить';
                        remove.addEventListener('click', () => {
                            if (confirm('Удалить пост?')) {
                                posts.splice(index, 1);
                                localStorage.setItem('posts', JSON.stringify(posts));
                                window.location.reload();
                            }
                        })
                        top.appendChild(remove)
                    }
                    postDiv.appendChild(top);

                    if (post.image) {
                        const postImage = document.createElement('span');
                        postImage.style.width = '500px';
                        postImage.style.height = '500px';
                        postImage.style.borderRadius = '10px';
                        postImage.style.background = 'url('+post.image+') no-repeat center';
                        postImage.style.backgroundSize = 'contain';
                        postDiv.appendChild(postImage);
                    }
                    if (post.content) {
                        const postContent = document.createElement('p');
                        postContent.textContent = post.content
                        postContent.style.padding = '5px 10px';
                        postDiv.appendChild(postContent);
                    }
                    if (post.actions) {
                        const postActions = document.createElement('div');
                        postActions.style.display = 'flex';
                        postActions.style.justifyContent = 'center';
                        postActions.style.alignItems = 'center';
                        postActions.style.width = '100%';
                        postActions.style.padding = '5px 10px';

                        const disLike = document.createElement('span');
                        disLike.style.padding = '5px 10px';
                        disLike.textContent = '👎';
                        disLike.style.cursor = 'pointer';
                        disLike.addEventListener('click', ()=> {
                            posts[index].actions.like--;
                            localStorage.setItem('posts', JSON.stringify(posts));
                            window.location.reload();
                        })

                        const likes = document.createElement('span');
                        likes.style.padding = '5px 10px';
                        likes.textContent = post.actions.like > 0 ? '+'+post.actions.like : post.actions.like;
                        likes.style.fontWeight = 'bold';
                        if(post.actions.like !== 0){
                            likes.style.color = post.actions.like > 0 ? 'green' : 'red';
                        }

                        const like = document.createElement('span');
                        like.style.padding = '5px 10px';
                        like.textContent = '👍';
                        like.style.cursor = 'pointer';
                        like.addEventListener('click', ()=> {
                            posts[index].actions.like++;
                            localStorage.setItem('posts', JSON.stringify(posts));
                            window.location.reload();
                        })

                        postActions.appendChild(disLike)
                        postActions.appendChild(likes)
                        postActions.appendChild(like)
                        postDiv.appendChild(postActions);
                    }
                    allPosts.appendChild(postDiv);
                })
                document.body.appendChild(allPosts);
            } else {
                noPost();
            }
        }
    }
    document.getElementById('username-label').innerText = currentUser;
})



function register(event) {
    const username = document.getElementById('username').value;
    const password1 = document.getElementById('password1').value;
    const password2 = document.getElementById('password2').value;

    if(password1 !== password2){
        alert('Пароли должны быть идентичны')
    }
    let users = localStorage.getItem('users');
    if(users){
        users = JSON.parse(users);
        let currentUser = users?.find(user => user.login === username);
        if(users.length > 0 && users?.find(user => user.login === username)){
            alert('Логин занят! Попробуйте другой');
            return;
        }
        users.push({
            login: username,
            password: password1
        });
    } else {
        users = [];
        users.push({
            login: username,
            password: password1
        });
    }
    localStorage.setItem('users', JSON.stringify(users));
    // window.open('login.html', '_self');
}

function login() {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const users = JSON.parse(localStorage.getItem('users') ?? '[]');
    const currentUser = users?.find(user => user.login === username && user.password === password);
    if(users && currentUser){
        localStorage.setItem('token', btoa('token'));
        localStorage.setItem('currentUser', username);
        window.open('index.html', '_self')
    } else {
        alert('Введены некорректные данные')
    }
}

function logout() {
    if (confirm('Вы хотите выйти из аккаунта?')) {
        localStorage.removeItem('token');
        localStorage.removeItem('currentUser');
        window.location.reload();
    }
}

function PreviewImage() {
    var oFReader = new FileReader();
    oFReader.readAsDataURL(document.getElementById("uploadImage").files[0]);

    oFReader.onload = function (oFREvent) {
        document.getElementById("uploadPreview").removeAttribute('hidden')
        document.getElementById("uploadPreview").src = oFREvent.target.result;
    };
}

function save() {
    if (confirm('Запостить это?')) {
       const localPosts = localStorage.getItem('posts');
        if(localPosts){
            const posts = JSON.parse(localPosts);
            console.log(document.getElementById("uploadImage").files[0])
            post = {
                content: document.getElementById("uploadContent").textContent,
                actions: {
                    like: 0
                },
                author: localStorage.getItem('currentUser')
            }

            let c = document.createElement('canvas');
            let img = document.getElementById('uploadPreview');
            c.height = img.naturalHeight;
            c.width = img.naturalWidth;
            let ctx = c.getContext('2d');
            ctx.drawImage(img, 0, 0, c.width, c.height);

            post.image = c.toDataURL();

            posts.push(post)
            localStorage.setItem('posts', JSON.stringify(posts));
        } else {
            post = {
                content: document.getElementById("uploadContent").textContent,
                actions: {
                    like: 0
                },
                author: localStorage.getItem('currentUser')
            }
            let c = document.createElement('canvas');
            let img = document.getElementById('uploadPreview');
            c.height = img.naturalHeight;
            c.width = img.naturalWidth;
            let ctx = c.getContext('2d');
            ctx.drawImage(img, 0, 0, c.width, c.height);

            post.image = c.toDataURL();
            const newPosts = [];
            newPosts.push(post);
            localStorage.setItem('posts', JSON.stringify(newPosts));
        }
        window.open('index.html', '_self')
    }
}
